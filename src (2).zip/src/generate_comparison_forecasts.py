"""Generate side-by-side next-session forecasts from full and monthly-sampled data."""
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LogisticRegression

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "processed"
DATASETS = {
    "Full corpus": DATA_DIR / "model_dataset.csv",
    "Monthly sampled 2026": DATA_DIR / "model_dataset_sampled_monthly_2026.csv",
}
OUTPUT = DATA_DIR / "latest_forecast_comparison.csv"
TARGET = "target_next_session_return_pct"
MARKET_FEATURES = ["daily_return_pct", "return_lag1", "return_lag2", "return_lag5", "volatility_5", "article_count", "unique_sources"]
SENTIMENT_FEATURES = MARKET_FEATURES + ["mean_sentiment", "positive_fraction", "negative_fraction", "neutral_fraction", "sentiment_lag1"]
VOLATILITY_FEATURES = ["daily_return_pct", "return_lag1", "return_lag2", "return_lag5", "return_lag10", "volatility_5", "volatility_20", "momentum_5", "momentum_10", "article_count", "unique_sources", "mean_sentiment", "median_sentiment", "positive_fraction", "negative_fraction", "neutral_fraction"]


def add_features(df):
    df = df.sort_values("date").reset_index(drop=True).copy()
    r = pd.to_numeric(df["daily_return_pct"], errors="coerce")
    df["return_lag1"] = r.shift(1)
    df["return_lag2"] = r.shift(2)
    df["return_lag5"] = r.shift(5)
    df["return_lag10"] = r.shift(10)
    df["volatility_5"] = r.rolling(5, min_periods=5).std()
    df["volatility_20"] = r.rolling(20, min_periods=10).std()
    df["momentum_5"] = r.rolling(5, min_periods=5).sum()
    df["momentum_10"] = r.rolling(10, min_periods=10).sum()
    df["sentiment_lag1"] = pd.to_numeric(df["mean_sentiment"], errors="coerce").shift(1)
    df["abs_return"] = r.abs()
    threshold = df["abs_return"].rolling(252, min_periods=60).quantile(0.80)
    target = pd.to_numeric(df[TARGET], errors="coerce")
    df["volatility_threshold_pct"] = threshold
    df["is_volatile_next_session"] = np.where(threshold.notna() & target.notna(), (target.abs() > threshold).astype(float), np.nan)
    return df


def fit_one(label, path):
    if not path.exists():
        raise FileNotFoundError(f"Required dataset missing for {label}: {path}\nRun the dataset-building stages first.")
    df = pd.read_csv(path, parse_dates=["date"])
    required = set(["date", "daily_return_pct", TARGET, "mean_sentiment", "median_sentiment", "positive_fraction", "negative_fraction", "neutral_fraction", "article_count", "unique_sources"])
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"{path.name} is missing required columns: {sorted(missing)}")
    df = add_features(df)
    latest = df.iloc[[-1]].copy()
    if pd.isna(latest["date"].iloc[0]):
        raise ValueError(f"{path.name} has no valid latest date")
    train = df.dropna(subset=[TARGET]).copy()
    if len(train) < 300:
        raise ValueError(f"Only {len(train)} training rows in {path.name}; need at least 300")
    y = train[TARGET].astype(float)
    y_dir = (y > 0).astype(int)
    if y_dir.nunique() < 2:
        raise ValueError(f"Training target has only one direction class in {path.name}")
    market_reg = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge(alpha=10.0))
    sentiment_reg = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge(alpha=10.0))
    market_clf = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), LogisticRegression(max_iter=1000, random_state=42))
    sentiment_clf = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), LogisticRegression(max_iter=1000, random_state=42))
    market_reg.fit(train[MARKET_FEATURES], y)
    sentiment_reg.fit(train[SENTIMENT_FEATURES], y)
    market_clf.fit(train[MARKET_FEATURES], y_dir)
    sentiment_clf.fit(train[SENTIMENT_FEATURES], y_dir)
    origin = pd.Timestamp(latest["date"].iloc[0]).strftime("%Y-%m-%d")
    result = {
        "dataset": label,
        "dataset_file": path.name,
        "forecast_origin_date": origin,
        "created_at_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "training_rows": len(train),
        "market_predicted_return_pct": float(market_reg.predict(latest[MARKET_FEATURES])[0]),
        "market_probability_up": float(market_clf.predict_proba(latest[MARKET_FEATURES])[0, list(market_clf.named_steps['logisticregression'].classes_).index(1)]),
        "sentiment_predicted_return_pct": float(sentiment_reg.predict(latest[SENTIMENT_FEATURES])[0]),
        "sentiment_probability_up": float(sentiment_clf.predict_proba(latest[SENTIMENT_FEATURES])[0, list(sentiment_clf.named_steps['logisticregression'].classes_).index(1)]),
        "volatility_probability": np.nan,
        "volatility_threshold_pct": float(latest["volatility_threshold_pct"].iloc[0]) if pd.notna(latest["volatility_threshold_pct"].iloc[0]) else np.nan,
        "warnings": "Probabilities are not demonstrated calibrated; use features only if available by forecast cutoff.",
    }
    result["market_direction"] = "UP" if result["market_predicted_return_pct"] >= 0 else "DOWN"
    result["sentiment_direction"] = "UP" if result["sentiment_predicted_return_pct"] >= 0 else "DOWN"
    vol_train = train.loc[train["is_volatile_next_session"].notna()].copy()
    if len(vol_train) >= 300 and vol_train["is_volatile_next_session"].nunique() >= 2 and pd.notna(result["volatility_threshold_pct"]):
        vol_model = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), LogisticRegression(max_iter=2000, random_state=42))
        vol_model.fit(vol_train[VOLATILITY_FEATURES], vol_train["is_volatile_next_session"].astype(int))
        classes = list(vol_model.named_steps["logisticregression"].classes_)
        result["volatility_probability"] = float(vol_model.predict_proba(latest[VOLATILITY_FEATURES])[0, classes.index(1)])
    return result


def main():
    results = [fit_one(label, path) for label, path in DATASETS.items()]
    out = pd.DataFrame(results)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(OUTPUT, index=False, encoding="utf-8-sig")
    print("\n===== SIDE-BY-SIDE NEXT-SESSION FORECASTS =====")
    for row in results:
        print(f"\n{row['dataset']} ({row['dataset_file']})")
        print(f"Forecast origin: {row['forecast_origin_date']} | training rows: {row['training_rows']}")
        print(f"Market-only: {row['market_predicted_return_pct']:+.4f}% ({row['market_direction']}); P(UP)={row['market_probability_up']:.1%}")
        print(f"Market + sentiment: {row['sentiment_predicted_return_pct']:+.4f}% ({row['sentiment_direction']}); P(UP)={row['sentiment_probability_up']:.1%}")
        if pd.notna(row['volatility_probability']):
            print(f"Next-session volatility probability: {row['volatility_probability']:.1%}; threshold={row['volatility_threshold_pct']:.4f}%")
        else:
            print("Next-session volatility probability: unavailable")
        print(f"Warning: {row['warnings']}")
    print(f"\nSaved comparison report: {OUTPUT}")

if __name__ == "__main__":
    main()
